# Authors

> This page is powered by [contributors-img](https://contributors-img.web.app)

This package is a collective effort made by many great people working on various projects. You can click on the pictures below to see their contribution in detail.

## frictionless-py

<a href="https://github.com/frictionlessdata/frictionless-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/frictionless-py" />
</a>

## datapackage-py

<a href="https://github.com/frictionlessdata/datapackage-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/datapackage-py" />
</a>

## tableschema-py

<a href="https://github.com/frictionlessdata/tableschema-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-py" />
</a>

## tableschema-bigquery-py

<a href="https://github.com/frictionlessdata/tableschema-bigquery-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-bigquery-py" />
</a>

## tableschema-ckan-datastore-py

<a href="https://github.com/frictionlessdata/tableschema-ckan-datastore-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-ckan-datastore-py" />
</a>

## tableschema-elasticsearch-py

<a href="https://github.com/frictionlessdata/tableschema-elasticsearch-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-elasticsearch-py" />
</a>

## tableschema-pandas-py

<a href="https://github.com/frictionlessdata/tableschema-pandas-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-pandas-py" />
</a>

## tableschema-sql-py

<a href="https://github.com/frictionlessdata/tableschema-sql-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-sql-py" />
</a>

## tableschema-spss-py

<a href="https://github.com/frictionlessdata/tableschema-spss-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tableschema-spss-py" />
</a>

## tabulator-py

<a href="https://github.com/frictionlessdata/tabulator-py/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=frictionlessdata/tabulator-py" />
</a>
