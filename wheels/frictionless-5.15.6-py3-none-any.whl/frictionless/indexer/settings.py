from __future__ import annotations

# General

BLOCK_SIZE = 8096
BUFFER_SIZE = 1000
