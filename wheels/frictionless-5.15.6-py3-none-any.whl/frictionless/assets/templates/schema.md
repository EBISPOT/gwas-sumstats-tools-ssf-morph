## `schema`

{% for field in schema.fields %}
  {% include 'field.md' %}
{% endfor %}