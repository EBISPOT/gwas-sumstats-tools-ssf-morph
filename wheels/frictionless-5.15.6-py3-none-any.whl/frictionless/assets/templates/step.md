### `step`
{% for property, value in step.items() %}
- `{{ property }}` {{ value }}
{% endfor %}
