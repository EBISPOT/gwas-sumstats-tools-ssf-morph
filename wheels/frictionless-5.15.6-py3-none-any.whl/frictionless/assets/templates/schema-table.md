## `schema`

{{ schema.fields | tabulate() }}