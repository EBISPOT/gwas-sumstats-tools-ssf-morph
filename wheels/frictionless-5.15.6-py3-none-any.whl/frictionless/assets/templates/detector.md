## `detector`
{% for property, value in detector.items() %}
- `{{ property }}` {{ value }}            
{% endfor %}