from .inquiry import Inquiry
from .task import InquiryTask
