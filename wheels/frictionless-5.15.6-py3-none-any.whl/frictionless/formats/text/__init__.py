from .plugin import TextPlugin

__all__ = [
    "TextPlugin",
]
