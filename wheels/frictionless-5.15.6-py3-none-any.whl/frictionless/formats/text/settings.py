NAMES = ["license", "makefile"]
FORMATS = ["txt", "js", "ts", "r"]
