from .plugin import DocumentPlugin

__all__ = [
    "DocumentPlugin",
]
