from __future__ import annotations

# General

DEFAULT_SELECTOR = "table"
