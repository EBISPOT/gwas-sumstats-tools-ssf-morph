from .plugin import ImagePlugin

__all__ = [
    "ImagePlugin",
]
