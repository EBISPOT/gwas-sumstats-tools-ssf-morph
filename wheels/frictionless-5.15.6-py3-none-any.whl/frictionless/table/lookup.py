from typing import Any, Dict


class Lookup(Dict[str, Any]):
    pass
