from typing import Iterator

from .row import Row

IRowStream = Iterator[Row]
