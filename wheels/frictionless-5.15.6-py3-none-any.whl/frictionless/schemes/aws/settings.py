from __future__ import annotations

# General

DEFAULT_S3_ENDPOINT_URL = "https://s3.amazonaws.com"
