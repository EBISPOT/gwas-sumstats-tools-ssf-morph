from __future__ import annotations

# General

DEFAULT_CHUNK_SIZE = 100000000
