from __future__ import annotations

# General

DEFAULT_HTTP_TIMEOUT = 10
DEFAULT_SCHEMES = ["http", "https", "ftp", "ftps"]
