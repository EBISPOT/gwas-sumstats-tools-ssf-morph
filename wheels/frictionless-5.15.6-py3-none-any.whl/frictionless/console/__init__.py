# Register modules
from . import commands
from .console import console
