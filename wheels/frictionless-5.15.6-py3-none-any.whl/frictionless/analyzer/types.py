from typing import Any, Dict

IAnalysisReport = Dict[str, Any]
