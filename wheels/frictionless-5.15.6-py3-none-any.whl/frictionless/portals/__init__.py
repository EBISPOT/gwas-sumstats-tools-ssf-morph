from .ckan import *
from .github import *
from .zenodo import *
